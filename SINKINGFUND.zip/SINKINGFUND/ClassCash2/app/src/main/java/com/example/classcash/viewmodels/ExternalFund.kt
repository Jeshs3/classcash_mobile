package com.example.classcash.viewmodels

class ExternalFund {
}